const CACHE = 'trading-notebook-v1';
const APP_SHELL = [
  './',
  './trading_notebook_v6_xau_macro.html',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(c => c.addAll(APP_SHELL)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(resp => {
    if (resp.ok && event.request.method === 'GET') {
      const copy = resp.clone();
      caches.open(CACHE).then(c=>c.put(event.request, copy));
    }
    return resp;
  }).catch(()=>caches.match('./trading_notebook_v6_xau_macro.html'))));
});
