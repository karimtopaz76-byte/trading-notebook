Trading Notebook actualizado

Novedades:
- Nuevos campos de datos básicos, contexto, gestión, psicología y revisión.
- Capturas de pantalla por operación.
- Resultado con colores: verde (ganadora), rojo (perdedora), naranja (break even).
- Días registrados con color según resultados.
- Filtros combinables por activo, setup, resultado, dirección, sesión, contexto, error, disciplina y noticias.
- Exportación CSV con todos los nuevos campos.
- Compatible con operaciones antiguas: los campos nuevos aparecen vacíos hasta que se editen/creen nuevas operaciones.
